Before running the modules, make sure to authenticate by running either of the commands below

gcloud auth login

OR

gcloud auth application-default login
